import express from "express";
import {
  addPollution,
  getMyPollution,
  getLocationPLI,
} from "../controllers/pollutionController.js";
import protect from "../middleware/authMiddleware.js";

const router = express.Router();

// ✅ Add pollution data
router.post("/add", protect, addPollution);

// ✅ Get logged-in user's pollution records
router.get("/my", protect, getMyPollution);

// ✅ ✅ NEW: Location-wise Multi-Metal PLI (REQUIRED FOR COMPARISON)
router.get("/location-pli", protect, getLocationPLI);

export default router;
