import Pollution from "../models/Pollution.js";

/* =========================================================
   WHO SAFE LIMITS FOR KEY HEAVY METALS (mg/L or mg/kg)
   (Based on WHO drinking water guidelines)
========================================================= */
const WHO_LIMITS = {
  Pb: 0.01,    // Lead
  Cd: 0.003,   // Cadmium
  Zn: 3,
  Ni: 0.02,
  Cu: 2,
  Cr: 0.05,
};

/* =========================================================
   📌 PREDICT NEXT CONCENTRATION USING SIMPLE REGRESSION
========================================================= */
const predictNextValue = (values) => {
  if (values.length < 2) return null;

  const last = values[values.length - 1];
  const prev = values[values.length - 2];
  const slope = last - prev;

  return last + slope; // very simple linear prediction
};

/* =========================================================
   📌 ADD POLLUTION DATA (SAVE + ALERTS + AUTO CALCULATIONS)
========================================================= */
export const addPollution = async (req, res) => {
  const { location, metal, concentration, permissibleLimit } = req.body;

  try {
    if (!location || !metal || !concentration || !permissibleLimit) {
      return res.status(400).json({ message: "All fields required" });
    }

    // --- CALCULATIONS ---------------------
    const cf = concentration / permissibleLimit;
    const iGeo = Math.log2(concentration / (1.5 * permissibleLimit));
    const pli = cf;

    // --- WHO ALERT SYSTEM ----------------
    let whoStatus = "OK";
    let exceedFactor = 0;

    if (WHO_LIMITS[metal]) {
      if (concentration > WHO_LIMITS[metal]) {
        whoStatus = "DANGER";
        exceedFactor = (concentration / WHO_LIMITS[metal]).toFixed(1);
      }
    }

    // --- SAVE RECORD ---------------------
    const pollution = await Pollution.create({
      location,
      metal,
      concentration,
      permissibleLimit,
      cf,
      iGeo,
      pli,
      whoStatus,
      exceedFactor,
      user: req.user.id,
    });

    res.status(201).json(pollution);
  } catch (error) {
    res.status(500).json({
      message: "Pollution save failed",
      error: error.message,
    });
  }
};

/* =========================================================
   📌 GET USER POLLUTION DATA + PREDICTIONS
========================================================= */
export const getMyPollution = async (req, res) => {
  try {
    const data = await Pollution.find({ user: req.user.id }).sort({
      createdAt: 1, // oldest → newest for forecasting
    });

    // GROUP BY METAL (for forecasting)
    const metalGroups = {};
    data.forEach((item) => {
      if (!metalGroups[item.metal]) metalGroups[item.metal] = [];
      metalGroups[item.metal].push(item.concentration);
    });

    // CREATE PREDICTION OBJECT
    const predictions = {};
    for (let metal in metalGroups) {
      predictions[metal] = predictNextValue(metalGroups[metal]);
    }

    res.json({
      records: data,
      predictions,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch pollution data",
      error: error.message,
    });
  }
};

/* =========================================================
   📌 LOCATION-WISE MULTI-METAL PLI + HAZARD INDEX (HI)
========================================================= */
export const getLocationPLI = async (req, res) => {
  try {
    const groupedData = await Pollution.aggregate([
      {
        $group: {
          _id: "$location",
          metals: { $push: "$metal" },
          cfs: { $push: "$cf" },
        },
      },
    ]);

    const result = groupedData.map((item) => {
      const cfList = item.cfs;
      const product = cfList.reduce((acc, val) => acc * val, 1);
      const n = cfList.length;

      const multiMetalPLI = Math.pow(product, 1 / n);

      // HAZARD INDEX (HI)
      const hazardIndex = cfList.reduce((acc, val) => acc + val, 0);

      return {
        location: item._id,
        metals: item.metals,
        cfValues: item.cfs,
        multiMetalPLI,
        hazardIndex,
      };
    });

    res.json(result);
  } catch (error) {
    res.status(500).json({
      message: "Multi-metal PLI calculation failed",
      error: error.message,
    });
  }
};
